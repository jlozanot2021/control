% Adapted from https://www.ensta-bretagne.fr/jaulin/

% State x = (x(1),x(2))


function e_6p6_draw(t,x,hatx,y)
    
    yeyeyeye = 1.1241231
    plot(t,x,'k--.',t,hatx,'b--.',t,y,'g--.')

  
end